#!/bin/sh

ServerPort=$(awk -F "=" '/ServerPort/ {print $2}' /var/1C/licence/3.0/licenceserver.conf)
if [ "$ServerPort" == "" ]; then
	ServerPort=9099
fi

xdg-open http://localhost:$ServerPort